//package com.mp.demo.config;
//
//import com.baomidou.mybatisplus.extension.plugins.PaginationInterceptor;
//import org.mybatis.spring.annotation.MapperScan;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
///**
// * MybatisPlus配置类
// * @Author Sans
// * @CreateTime 2019/5/26 17:20
// */
//@Configuration
//@MapperScan(basePackages = {"com.mp.**.dao"}) //扫描DAO
//public class MybatisPlusConfig {
//    /**
//     * 分页插件
//     */
//    @Bean
//    public PaginationInterceptor paginationInterceptor() {
//        return new PaginationInterceptor();
//    }
//}