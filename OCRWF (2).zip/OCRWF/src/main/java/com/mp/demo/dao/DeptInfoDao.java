package com.mp.demo.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mp.demo.entity.DeptInfoEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * 部门信息Dao
 * @Author Sans
 * @CreateTime 2020/8/29
 */
@Mapper
public interface DeptInfoDao extends BaseMapper<DeptInfoEntity> {
}