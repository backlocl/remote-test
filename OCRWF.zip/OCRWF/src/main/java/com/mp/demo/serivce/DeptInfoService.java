package com.mp.demo.serivce;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mp.demo.entity.DeptInfoEntity;

/**
 * 部门业务接口
 * @Author Sans
 * @CreateTime 2020/8/29
 */
public interface DeptInfoService extends IService<DeptInfoEntity> {

}